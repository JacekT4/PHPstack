<h1 class="fw-light">Strona domowa</h1>
<p>
  Pozostale linki
</p>
<p>
  <a href="/kalendarz" class="btn btn-secondary my-2">Kalendarz</a>
  <a href="/dzialanie" class="btn btn-secondary my-2">Dzialania</a>
  <a href="/obecnywynik" class="btn btn-secondary my-2">Obecny wynik</a>
  <a href="/emaile" class="btn btn-secondary my-2">Emaile</a>
  <a href="/ksiazki" class="btn btn-secondary my-2">Ksiazki</a>
  <a href="/baza" class="btn btn-secondary my-2">Baza</a>
</p>